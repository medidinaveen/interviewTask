app.service('datasrvc', function ($window) {
    this.users=[{"name":"jaya","role":"developer","dob":"2019-02-10T12:37:04.922Z","address":"madhapur","img":"https://sunlimetech.com/portfolio/boot4menu/assets/imgs/team/img_01.png"},
                {"name":"ram","role":"developer","dob":"2019-02-10T12:37:04.922Z","address":"madhapur","img":"https://sunlimetech.com/portfolio/boot4menu/assets/imgs/team/img_02.png"},
                {"name":"siri","role":"developer","dob":"2019-02-10T12:37:04.922Z","address":"madhapur","img":"https://sunlimetech.com/portfolio/boot4menu/assets/imgs/team/img_03.png"},
                {"name":"praveen","role":"developer","dob":"2019-02-10T12:37:04.922Z","address":"madhapur","img":"https://sunlimetech.com/portfolio/boot4menu/assets/imgs/team/img_04.jpg"},
                {"name":"naveen","role":"developer","dob":"2019-02-10T12:37:04.922Z","address":"madhapur","img":"https://sunlimetech.com/portfolio/boot4menu/assets/imgs/team/img_05.png"}]
    this.updateData = function () {
       // this.users = newMessage;
        
        /*debugger*/
       //  return this.user;
    }
       
        this.getData= function (){
           
             return this.users;
        }
    
});