var app = angular.module("myApp", ["ngRoute","ngIdle"]);
app.run(function($rootScope,user,$window) {
     var id= $window.localStorage.getItem('user');
      
     if(id){
       // user.setUser();
      $rootScope.session=user.validuser();
     }else{
       // user.setUser();
     $rootScope.session=user.validuser();
 }
    });
app.config(function(IdleProvider, KeepaliveProvider) {
            IdleProvider.idle(1);
            IdleProvider.timeout(4);
            KeepaliveProvider.interval(1);
        });

app.config(function($routeProvider) {
    $routeProvider
    .when("/dashboard", {
        templateUrl : "html/main.html",
        resolve:{ "check":function($location,user){   //function to be resolved, accessFac and $location Injected
            if( user.validuser()=='admin'){    //check if the user has permission -- This happens before the page loads
            }else{
                $location.path("/");                //redirect user to home if it does not have permission.
                //alert("You don't have access here");
            }
        }
    }
    })
    .when("/", {
        templateUrl : "html/login.html",
        controller:"login"
    })
    .when("/red", {
        templateUrl : "html/red.html",
        controller:"adminctrl",
		 resolve:{ "check":function($location,user){   //function to be resolved, accessFac and $location Injected
            if( user.validuser()=='admin'){    //check if the user has permission -- This happens before the page loads
            }else{
                $location.path("/");                //redirect user to home if it does not have permission.
              //  alert("You don't have access here");
            }
        }
    }
    })
    .when("/green", {
        templateUrl : "html/green.html",
        controller:"employeectrl",
        resolve:{ "check":function($location,user){   //function to be resolved, accessFac and $location Injected
            if( user.validuser()=='user'){    //check if the user has permission -- This happens before the page loads
            }else{
                $location.path("/");                //redirect user to home if it does not have permission.
               // alert("You don't have access here");
            }
        }
    }
    })
    .when("/blue", {
        templateUrl : "html/blue.html",
        controller:"login",
        resolve:{ "check":function($location,user){   //function to be resolved, accessFac and $location Injected
            if( user.validuser()=='user'){    //check if the user has permission -- This happens before the page loads
            }else{
                $location.path("/");                //redirect user to home if it does not have permission.
               // alert("You don't have access here");
            }
        }
    }
    });
});
