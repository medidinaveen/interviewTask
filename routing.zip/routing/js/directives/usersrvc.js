app.service('user', function ($window) {
    //this.user =""
    this.setUser = function (newMessage) {
        this.user = newMessage;
        $window.localStorage.setItem('user', this.user);
        /*debugger*/
       //  return this.user;
    }
       
        this.validuser= function (){
            //this.session="";
            if($window.localStorage.getItem('user')){
                  this.session=$window.localStorage.getItem('user');
            }else{
                 this.session=false;
            }
            /*debugger*/
             return this.session;
        }
    
});