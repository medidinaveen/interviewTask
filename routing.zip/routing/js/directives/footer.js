app.directive('footer1', footerDirective);
function footerDirective() {
    return {
        bindToController: false,
        controller: FooterController,
        controllerAs: 'vm',
        restrict: 'EA',
        scope: {
            controller: '='
        },
        templateUrl: 'html/footer.html'
    };
 
    function FooterController($scope) {
        //$scope.not={"notifications":22,"messages":2,}
        console.log("footer loaded");
    }
};