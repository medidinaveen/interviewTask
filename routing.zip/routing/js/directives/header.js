app.directive('header', headerDirective);
function headerDirective() {
     var linkFunction = function(scope, element, attributes) {
    scope.text = attributes["header"];
    debugger
  };
    return {
        bindToController: true,
        controller: HeaderController,
        controllerAs: 'vm',
        restrict: 'EA',
        scope: {
            controller: '='
        },
        templateUrl: 'html/header.html',
        link:linkFunction
    };
 
    function HeaderController($scope,user,$location,$rootScope,$window) {
        $scope.not={"notifications":22,"messages":2,}
        $scope.session=user.validuser();
        $scope.logout=function(){
            user.setUser("");
            $window.localStorage.removeItem("user");
            $rootScope.session=user.validuser();
             $location.path("/");
        }
    }
};