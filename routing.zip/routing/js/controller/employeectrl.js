app.controller('employeectrl', function($scope,$location,$rootScope,datasrvc) {
 
  $scope.employee=datasrvc.getData()[0];
  
  debugger
});