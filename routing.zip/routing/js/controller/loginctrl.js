app.controller('login', function($scope,user,$location,$rootScope,Idle, Keepalive,$window) {
  $scope.username = "";
  $scope.password = "";
  $scope.login= function(){
    if($scope.username=='admin'&&$scope.password=='123456'){
        user.setUser('admin');
        $rootScope.session=user.validuser();
        $location.path("/dashboard");
        Idle.watch();
        

    }else if($scope.username=='user'&&$scope.password=='123456'){
    	user.setUser('user');
        $rootScope.session=user.validuser();
        $location.path("/green");
       Idle.watch();
    }
  }
    
      $rootScope.$on('IdleStart', function() {
      
      });

      $rootScope.$on('IdleEnd', function() {
        
      });

      $rootScope.$on('IdleTimeout', function() {
       // alert("done");
        user.setUser("");
            $window.localStorage.removeItem("user");
            $rootScope.session=user.validuser();
             $window.location.reload();

      });

});