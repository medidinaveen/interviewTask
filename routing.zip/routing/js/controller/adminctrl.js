app.controller('adminctrl', function($scope,$location,$rootScope,datasrvc) {
 
  $scope.employees=datasrvc.getData();
  
});